﻿using System;

namespace test.REPOSITORY
{
    public class Class1
    {
    }
}
