using System;
using System.Collections.Generic;

namespace test.REPOSITORY
{
    public interface IInvoiceRepository
    {
 
        decimal? GetTotal(int invoiceId);
        decimal GetTotalOfUnpaid();
        IReadOnlyDictionary<string, long> GetItemsReport(DateTime? from, DateTime? to);
    } 
    
}