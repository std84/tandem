using System;
using System.Collections.Generic;
using System.Linq;
using test.MODAL;

namespace test.REPOSITORY
{
    public class InvoiceRepository : IInvoiceRepository
    {
        IQueryable<Invoice> _invoices;
        public InvoiceRepository(IQueryable<Invoice> invoices)
        {
            
            if(invoices == null){
                throw new NotImplementedException();
            }
            this._invoices = invoices;
            // Console.WriteLine("Sample debug output");
        }
           /// Should return a dictionary where the name of an invoice item is a key and the number of bought items is a value.
        /// The number of bought items should be summed within a given period of time (from, to). Both the from date and the end date can be null.
        public IReadOnlyDictionary<string, long> GetItemsReport(DateTime? from, DateTime? to)
        { 
            var resinvoice = this._invoices.ToList();
            var res = [];
            IDictionary<string, long> restwo = new Dictionary<string, long>();
            foreach (Invoice element in resinvoice)
            {
                var list = element.InvoiceItems;
                long count =0;
                foreach (InvoiceItem elementtwo in list)
                {
                    count = count + (long)(elementtwo.Count);
    
                }

            
                restwo.Add(element.ToString(), count);
    
            }
            return (IReadOnlyDictionary<string, long>)restwo;
        }
  /// Should return a total value of an invoice with a given id. If an invoice does not exist null should be returned.
        public decimal? GetTotal(int invoiceId)
        {
            if(this._invoices == null)
                return null;
           var resinvoice = this._invoices.Select(p => p.Id == invoiceId).ToList();
           if(resinvoice == null)
                return null;
             decimal res =0;
            var list = this._invoices.Select(p => p.InvoiceItems).ToList();
            foreach (InvoiceItem element in list)
            {
                res = res + element.Price;
    
            }
            return res;
        }
     /// Should return a total value of all unpaid invoices.
        public decimal GetTotalOfUnpaid()
        {
            decimal res =0;
            var list = this._invoices.ToList();
            foreach (Invoice element in list)
            {
                if(element.AcceptanceDate == null)
                res = res +1;
    
            }
            return res;
        }
    }
}