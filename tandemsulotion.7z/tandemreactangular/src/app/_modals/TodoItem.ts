export interface ToDoItem {
  
    name: string;
    isDone: boolean;
}
