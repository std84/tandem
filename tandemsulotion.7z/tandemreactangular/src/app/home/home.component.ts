import { Component, OnInit } from '@angular/core';
import { ToDoItem } from '../_modals/TodoItem';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  TodoItems: ToDoItem[];
  itemsDone = 0;
  ItemLeft = 0;
  newtask = '';
  constructor() { }

  ngOnInit() {
    this.TodoItems = [];
  }
  handleDone(idx){

    if(this.TodoItems[idx].isDone  === false) {
      this.itemsDone += 1;
    }
    else {
      this.itemsDone -= 1;
    }
    this.TodoItems[idx].isDone = !this.TodoItems[idx].isDone ;
    this.ItemLeft = this.TodoItems.length - this.itemsDone;
  

  }
  addTodoItem(){
    const newItem = {name: this.newtask, isDone: false};
  
    this.TodoItems.push(newItem);
  }
}
