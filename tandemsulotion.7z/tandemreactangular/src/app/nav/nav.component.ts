import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {

  toggleNavbar = false;
  navtype = 1;
  showLogIn = false;
  categories: any;
  constructor(private router: Router, private route: ActivatedRoute) { 
  }
  ngOnInit() {
  }
  showLog() {
    this.showLogIn = !this.showLogIn;
  }
  collapse() {
    this.toggleNavbar = !this.toggleNavbar;
  }


}
